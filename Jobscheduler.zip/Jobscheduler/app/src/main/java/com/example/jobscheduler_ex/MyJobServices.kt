package com.example.jobscheduler_ex

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.PendingIntent.FLAG_IMMUTABLE
import android.app.job.JobParameters
import android.app.job.JobService
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.content.getSystemService
import com.example.jobscheduler_ex.NotificationEx


 class MyJobServices: JobService() {
     lateinit var btnNotify: Button

     @RequiresApi(Build.VERSION_CODES.O)
     override fun onStartJob(p0: JobParameters?): Boolean {
         Log.d("TAG", "onSartJon:")
         val intent = Intent(this@MyJobServices, NotificationEx::class.java)
         var pendingIntent = PendingIntent.getBroadcast(
             this@MyJobServices, 234, intent, FLAG_IMMUTABLE)
         val notificationManager =
             getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
//         notificationManager.createNotificationChannel(
         Toast.makeText(this, "Notification Sent", Toast.LENGTH_LONG).show()

         btnNotify.setOnClickListener {
             val intent = Intent(this, NotificationEx::class.java)
             pendingIntent = PendingIntent.getActivity(
                 this, 0, intent, FLAG_IMMUTABLE)



//        notificationManager.set(AlarmManager.RTC_WAKEUP,System.currentTimeMillis(),pendingIntent)
//        Toast.makeText(this@MyJobServices,"Alarm Set ", Toast.LENGTH_LONG ).show()


         }
         return true
     }

        override fun onStopJob(p0: JobParameters?): Boolean {
            Log.d("Tag", "onStopJob:")
            return true
        }

}
