package com.example.jobscheduler_ex

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.res.Resources
import android.graphics.BitmapFactory
import android.graphics.Color
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.widget.Button
import android.widget.RemoteViews

class NotificationEx {
    lateinit var resources: Resources
    lateinit var notificationManager : NotificationManager
    lateinit var notificationChannel: NotificationChannel
    lateinit var builder: Notification.Builder
    lateinit var btnNotify : Button
    lateinit var remoteCollapsedView: RemoteViews
    lateinit var remoteExpandedViews: RemoteViews
    lateinit var pendingIntent: PendingIntent
    lateinit var soundUri: Uri
    lateinit var audioAttr: AudioAttributes
    lateinit var remoteInput: RemoteInput
    private val channelId = "MY CHANNEL ID"
    private val description = "Test Notification"
    private val title = "Notification"
    val myKey = "Remote key"
    val notificationId=1234

    private fun myNotificationChannel() {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            notificationChannel = NotificationChannel(channelId,description, NotificationManager.IMPORTANCE_HIGH)
            notificationChannel.enableLights(true)
            notificationChannel.lightColor = Color.GREEN
            notificationChannel.enableVibration(true)
            notificationChannel.setSound(soundUri,audioAttr)
            notificationManager.createNotificationChannel(notificationChannel)

            builder = Notification.Builder(this,channelId)
                .setSmallIcon(R.drawable.a)
                .setContentTitle(title)
                .setContentText(description)
                .setLargeIcon(BitmapFactory.decodeResource(this.resources,R.drawable.a))
                .setContentIntent(pendingIntent)

                .setCustomContentView(remoteCollapsedView)
                .setCustomBigContentView(remoteExpandedViews)
                .setAutoCancel(true)
        }

        else{
            builder = Notification.Builder(this)
                .setSmallIcon(R.drawable.a)
                .setContentTitle(title)
                .setContentText(description)
                .setLargeIcon(BitmapFactory.decodeResource(this.resources,R.drawable.a))
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)

        }
    }
}