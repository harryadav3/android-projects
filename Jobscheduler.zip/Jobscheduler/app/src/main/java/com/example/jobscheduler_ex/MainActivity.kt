package com.example.jobscheduler_ex

import MyJobServices
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.os.Bundle
import android.os.PersistableBundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.getSystemService

class MainActivity :AppCompatActivity() {
    var jobScheduler: JobScheduler? = null

    override fun onCreate(savedInstanceState: Bundle?, persistentState: PersistableBundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val stopJob = findViewById<Button>(R.id.stop)
        val startJob = findViewById<Button>(R.id.start)

        startJob.setOnClickListener{
            jobScheduler = getSystemService(JOB_SCHEDULER_SERVICE) as JobScheduler
            val componentName =ComponentName(this, MyJobServices::class.java)
            val builder = JobInfo.Builder(123, componentName)
            builder.setMinimumLatency(8000)
            builder.setOverrideDeadline(10000)
            builder.setPersisted(true)
            builder.setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
            builder.setRequiresCharging(false)
            jobScheduler!!.schedule(builder.build())


        }

        stopJob.setOnClickListener {
            if(jobScheduler != null){
                jobScheduler!!.cancel(123)
                jobScheduler = null
                Toast.makeText(this,"Job Cancelled" ,Toast.LENGTH_SHORT).show()
            }
        }
    }

}